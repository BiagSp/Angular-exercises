# Angular - Exercise 2

Creare un componente User-details, nel file .ts salvare l'oggetto user di tipo User (Typescript Esercizio 1), mostrare le proprietà di questo oggetto nel file html. *Formattare la data di nascita nel seguente formato 14 Dec 1995*
