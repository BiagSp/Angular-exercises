# Angular Exercise 5

Partendo dall'esercizio precedente, nel componente users-single aggiungere un button che permette di rimuovere quell'elemento dalla lista emettendo un evento al componente padre.

