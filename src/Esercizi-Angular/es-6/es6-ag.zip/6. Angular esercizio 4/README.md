# Angular Exercise 4

Partendo dall'esercizio precedente, creare un componente user-single, che verrà iterato nella lista e prenderà come `@Input()` un singolo elemento della lista

