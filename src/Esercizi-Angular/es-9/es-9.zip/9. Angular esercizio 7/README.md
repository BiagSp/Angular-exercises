# Angular Exercise 7

Partendo dall'esercizio precedente, stilizzare tutti gli elementi della lista, con un bordo colorato, in base al ruolo dell'utente.

