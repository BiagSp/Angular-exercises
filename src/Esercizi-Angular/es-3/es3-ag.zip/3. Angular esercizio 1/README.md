# Angular - Exercise 1

Replicare la seguente struttura su angular

Extra: Replicare anche il layout oltre la struttura

*Consiglio: Per risolvere gli esercizi su Angular, creare un progetto vuoto attraverso la CLI, e creare un un branch a partire da master per ogni esercizio.*

![struttura-esercizio-1](D:\Lavori\Develhope\Tutor\Esercizi\angular\3. Angular esercizio 1\struttura-esercizio-1.png)

