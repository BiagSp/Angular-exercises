# Angular Exercise 6

Partendo dall'esercizio precedente, Aggiungere un controllo sulla lista utenti, se la lista è popolata mostrarla, altrimenti mostrare un messaggio "Non sono presenti utenti"

